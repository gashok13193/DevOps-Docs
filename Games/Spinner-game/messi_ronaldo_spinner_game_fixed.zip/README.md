# Messi vs Ronaldo Spinner — FIXED

Winner detection now uses the actual final direction of the pointer.

- Pointer left of the center line -> MESSI PUT A GOAL
- Pointer right of the center line -> RONALDO PUT A GOAL
- Wide center zone (22 degrees on either side of the center) -> CENTER / NO GOAL
- The visible center line is wide and clearly marked.
- The pointer starts pointing downward, so the left/right calculation matches what you see on screen.

Run:
    sudo python3 server.py

Open:
    http://127.0.0.1:100

Android on same Wi-Fi:
    http://YOUR-PC-IP:100
