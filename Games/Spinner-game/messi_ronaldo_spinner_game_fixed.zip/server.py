#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import os
PORT=100
os.chdir(os.path.dirname(os.path.abspath(__file__)))
class Handler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        print("%s - %s" % (self.address_string(), format % args))
server=ThreadingHTTPServer(("0.0.0.0",PORT),Handler)
print("Messi vs Ronaldo Spinner running on port 100")
print("Computer: http://127.0.0.1:100")
print("Android: http://<PC-LAN-IP>:100")
try: server.serve_forever()
except KeyboardInterrupt: pass
finally: server.server_close()
